-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

INSERT INTO `tb_rotw` (`idrotw`, `nama`, `judullagu`, `artis`, `alasan`, `insertedon`, `insertedby`, `updatedon`, `updatedby`) VALUES
(1944,	'Claudia Valencia',	'My Universe',	'Coldplay & BTS',	'Lagunya easy to listen dan moodbooster banget ',	'2021-09-25 11:13:01',	'Claudia',	'2021-09-25 11:13:01',	'Claudia'),
(1945,	'Elisabet Tening',	'Evergreen',	'Birdy',	'Lagu ini ada di album terbaru Birdy, Young Heart, yang dia klaim sebagai album patah hati. Mari rayakan patah hati bersama Birdy :\')',	'2021-09-25 16:42:45',	'elis',	'2021-09-25 16:42:45',	'elis'),
(1946,	'Putri Riri	Gustini',	'Anybody else but me',	'FUR',	'All of my life, all the people in my mind. Kutipan tersebut yang bikin sukak ama lagu ini yeahh',	'2021-09-26 07:48:47',	'riri',	'2021-09-27 07:47:59',	'riri');

-- 2021-10-01 22:32:30
