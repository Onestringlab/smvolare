-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

INSERT INTO `tb_admin` (`idadmin`, `role`, `name`, `username`, `email`, `password`, `insertedby`, `insertedon`, `updatedby`, `updatedon`) VALUES
(17,	'Admin',	'Yulrio Brianorman',	'rionorman',	'rionorman@gmail.com',	'7b403c2a437be39498a6705739ed229e',	'rionorman',	'2012-03-29 20:40:05',	'rionorman',	'2015-12-05 07:39:24'),
(129,	'Penyiar',	'Renny Wahyu Utami',	'renny',	'',	'f357fc8df6498ebf32531300a615f6cf',	'elis',	'2019-04-26 14:16:08',	'elis',	'2019-04-26 15:30:10'),
(57,	'Kontributor',	'Farida Mulyati',	'yati',	'yatikenari@yahoo.com',	'60cbfb4becbc5b39c7c6acd2c7830081',	'rionorman',	'2015-11-23 08:47:29',	'rionorman',	'2015-12-06 15:29:59'),
(59,	'Admin',	'Dewi Utami',	'temi',	'temi@volarefm.com',	'44175f8344a58ecf4944c99c7ceef058',	'rionorman',	'2015-12-05 17:01:26',	'rionorman',	'2015-12-12 20:58:43'),
(60,	'Kontributor',	'Lim Ngin Tju',	'acu',	'limngintju@yahoo.co.id',	'c7b99db89d4c808b95a8672848f1f0af',	'rionorman',	'2015-12-05 07:40:29',	'elis',	'2020-11-30 11:51:05'),
(61,	'Penyiar',	'Eko Dony Prayudi',	'jerry',	'eko.dony.prayudi@gmail.com',	'8826d062932185dd5b69cad04a6d40b9',	'rionorman',	'2015-12-05 07:41:59',	'rionorman',	'2015-12-05 07:42:35'),
(62,	'Penyiar',	'Jaka Prakasa',	'jaka',	'jaka@volarefm.com',	'edce845d19745e812a249e8d719010b1',	'rionorman',	'2015-12-05 07:43:30',	'rionorman',	'2015-12-05 07:43:30'),
(131,	'Penyiar',	'Hafidh Ravy Pramanda',	'hafidh',	'',	'b3a191063bb36df22dd4226e91e876da',	'puspita',	'2019-05-28 19:03:44',	'elis',	'2020-10-04 09:57:21'),
(145,	'Penyiar',	'Ganis Sadeli',	'Ganis',	'',	'829fc3b0e745e74b0e303488cca99a92',	'puspita',	'2020-12-01 06:39:06',	'puspita',	'2020-12-01 06:39:06'),
(146,	'Admin',	'Bunga Avisa',	'Bunga',	'',	'1d252f306bcc1f620d17f7a3179d1ddb',	'puspita',	'2020-12-01 07:15:48',	'puspita',	'2020-12-01 07:15:48'),
(150,	'Penyiar',	'Novy Ramadhani',	'Novy',	'',	'72c9b55bde851604f7bc94bacc43a5ff',	'puspita',	'2021-01-29 16:18:31',	'puspita',	'2021-01-29 16:18:31'),
(71,	'Penyiar',	'Lisa Eka Sari',	'lisa',	'eka.eka75@yahoo.co.id',	'04e893d1dfeb58f395ec9e1685738065',	'rionorman',	'2015-12-05 07:51:16',	'elisadmin',	'2017-08-12 13:39:44'),
(73,	'Penyiar',	'Mateus Herman',	'herman',	'matman1034@yahoo.com',	'a7d1416954be6d1dcd79d73219efc2c2',	'rionorman',	'2015-12-05 07:52:48',	'rionorman',	'2015-12-05 07:52:48'),
(74,	'Penyiar',	'Nur Risqi Amalia',	'kiki',	'nurrisqiamalia@gmail.com',	'4558c62f302ddeb3f1dfd4911127deb6',	'rionorman',	'2015-12-05 07:53:31',	'puspita',	'2018-03-05 19:37:53'),
(75,	'Penyiar',	'Poltak Sabam Nainggolan',	'poltak',	'',	'187f79e20ff13877f73ac40c40214ac9',	'rionorman',	'2015-12-05 07:54:09',	'elisadmin',	'2016-05-09 19:16:41'),
(77,	'Penyiar',	'Putri Riri	Gustini',	'riri',	'Riri2994@gmail.com',	'576b6e41506ecb469c1743935f9d82b4',	'rionorman',	'2015-12-05 07:55:47',	'elisadmin',	'2016-05-20 08:44:08'),
(134,	'Penyiar',	'Giovanni Carissa Effendie',	'gio',	'',	'dab495ffb6fc1391216fd0f4d8e679f0',	'puspita',	'2019-11-02 16:02:04',	'puspita',	'2019-11-02 16:08:14'),
(135,	'Admin',	'Hesty Indrayani',	'hesty',	'',	'4c11ea64df687aac55d07b0a560f26c2',	'elis',	'2019-11-26 09:39:07',	'elis',	'2019-11-26 09:39:07'),
(82,	'Penyiar',	'Veny Sulika',	'veny',	'veny@volarefm.com',	'b30119011829634eecbd170352447216',	'rionorman',	'2015-12-05 08:00:26',	'elisadmin',	'2017-11-25 11:40:15'),
(147,	'Penyiar',	'Egydia',	'Egy',	'',	'ff8583958b84b702f4270890cdd08f6c',	'puspita',	'2020-12-12 17:49:58',	'puspita',	'2020-12-12 17:49:58'),
(84,	'Penyiar',	'-',	'-',	'',	'4735a0c4d1b11f62ea44115d54a93087',	'rionorman',	'2015-12-05 20:29:36',	'rionorman',	'2015-12-05 20:30:56'),
(85,	'Admin',	'Elisabet Tening',	'elis',	'elis@volarefm.com',	'de0dad9466d37b3d4d177ddad0bfe020',	'rionorman',	'2015-12-06 14:34:58',	'elisadmin',	'2018-05-12 15:05:50'),
(140,	'Penyiar',	'Hasbiyallah Dua Yanggi',	'yanggi',	'',	'7ec38b1b0cc5b1cf5fcf6a36f1661ef0',	'puspita',	'2020-02-27 13:34:43',	'puspita',	'2020-02-27 13:34:43'),
(87,	'Penyiar',	'Didi Sudingatono',	'didi',	'',	'588408ab4a52d6d125e6311e07c62965',	'rionorman',	'2015-12-15 14:45:36',	'rionorman',	'2015-12-23 18:34:19'),
(102,	'Penyiar',	'Witri Eka Yanggi',	'wiwit',	'',	'fc74ae07dd0f4864d3fc6e93d163cc33',	'elisadmin',	'2017-01-29 07:51:52',	'elisadmin',	'2017-01-29 07:51:52'),
(90,	'Kontributor',	'Aprianti',	'apri',	'',	'758a52868503f64ba1ad287e1238b0a3',	'rionorman',	'2016-01-13 14:42:46',	'rionorman',	'2016-01-13 14:43:42'),
(152,	'Penyiar',	'Claudia Valencia',	'Claudia',	'',	'a2f6e0da16d5785e53e1f6ac26c71cd7',	'puspita',	'2021-03-14 13:59:52',	'puspita',	'2021-03-14 13:59:52'),
(151,	'Kontributor',	'Melly Meliantha',	'melly',	'',	'e3b538505ee75a089836103f5328ec45',	'elis',	'2021-02-17 17:30:45',	'elis',	'2021-02-17 17:30:45'),
(108,	'Admin',	'Maya Nur Puspitasari',	'puspita',	'pit.puspita@gmail.com',	'7818ef31bf39ce866dc3b1d2ac19e928',	'elisadmin',	'2017-03-30 10:39:02',	'elisadmin',	'2017-08-31 12:12:10'),
(148,	'Admin',	'Rianti Alamanda Maulidya',	'lia',	'',	'a435c1c2d6cac10e94fc5440bff0cd3d',	'puspita',	'2020-12-14 12:48:19',	'puspita',	'2020-12-14 12:48:19'),
(130,	'Kontributor',	'Rasendrya Abdul Jabbar',	'drya',	'rasendrya16@gmail.com',	'f4be9e1fa406139467f9525a81bbb9b1',	'elis',	'2019-05-20 16:25:00',	'elis',	'2020-10-04 09:37:49'),
(142,	'Admin',	'Furry Sasty',	'furry',	'furry@volarefm.com',	'6c2d783f3d8296a5a19a3a090907a126',	'rionorman',	'2020-03-31 19:40:11',	'elis',	'2021-03-26 12:49:00'),
(144,	'Penyiar',	'Sulianti Putri',	'Suli',	'',	'61900b286815f327216641760a46de8f',	'puspita',	'2020-09-15 17:11:36',	'puspita',	'2020-09-15 17:11:36');

-- 2021-10-01 22:29:46
