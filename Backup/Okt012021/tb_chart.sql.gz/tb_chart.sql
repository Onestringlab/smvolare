-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

INSERT INTO `tb_chart` (`idchart`, `chart`, `program`, `tanggal`, `foto`, `tw1`, `song1`, `artis1`, `tw2`, `song2`, `artis2`, `tw3`, `song3`, `artis3`, `tw4`, `song4`, `artis4`, `tw5`, `song5`, `artis5`, `tw6`, `song6`, `artis6`, `tw7`, `song7`, `artis7`, `tw8`, `song8`, `artis8`, `tw9`, `song9`, `artis9`, `tw10`, `song10`, `artis10`, `updatedTime`, `updatedBy`) VALUES
(1,	'vnos',	'Volare #1 Sound',	'24 Maret 2019',	'https://ton.twitter.com/i/ton/data/dm/1110761498920378372/1110761447477248002/FU5rDooP.jpg',	'1',	'Exits',	'Foals',	'2',	'Don\'t Feel Like Crying',	'Sigrid',	'3',	'Harmony Hall',	'Vampire Weekend',	'4',	'Better Than Me',	'Ten Tonnes',	'5',	'Dylan Thomas',	'Better Oblivion Community Center',	'6',	'Are You Bored Yet? (Feat. Clairo)',	'Wallows',	'7',	'My Love Goes On (Feat. Joss Stone)',	'James Morrison',	'8',	'Give stupidity a chance',	'Pet Shop Boys',	'9',	'Knock Me Off My Feet',	'SOAK',	'10',	'Capacity',	'Charly Bliss',	'2019-03-27 04:52:02',	'nanak'),
(2,	'indo10',	'Indonesia 10',	'24 Maret 2019',	'https://ton.twitter.com/i/ton/data/dm/1110761590679175172/1110761566410928131/3rwKrXLR.jpg',	'1',	'Balada Insan Muda',	'Diskoria',	'2',	'Pleaser',	'Elephant Kind',	'3',	'Peluk',	'Riuh Sunyi',	'4',	'Masa-Masa',	'The Adams',	'5',	'Woo Woo (Feat. Leanna Rachel)',	'Sore',	'6',	'Pikiran dan Perjalanan',	'Barasura',	'7',	'Sabda Rindu',	'Manjakani',	'8',	'Senja Teduh Pelita',	'Maliq & d\'Essentials',	'9',	'WKNDCRUISIN\'',	'Teza Sumendra',	'10',	'Looking For (Feat. Mira Jasmine)',	'Kayman',	'2019-03-27 04:54:43',	'nanak');

-- 2021-10-01 22:29:51
